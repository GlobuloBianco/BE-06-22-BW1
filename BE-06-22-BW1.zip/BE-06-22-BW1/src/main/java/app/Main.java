package app;

import java.time.LocalDate;
import java.util.ArrayList;

import dao.TesseraDAO;
import dao.UtenteDAO;
import entities.Tessera;
import entities.Utente;

public class Main {
	static ArrayList<Utente> userList = new ArrayList<Utente>();
	static ArrayList<Tessera> tesList = new ArrayList<Tessera>();
	
	public static void main(String[] args) {
	
		//Utente senza tessera
		userList.add(UtenteDAO.creaUtente("Mario Rossi", "2002-05-05", "Via del lago 8", (TesseraDAO.creaTessera("1LAFJT", LocalDate.of(2023, 01, 05)).getNumeroTessera())));
		UtenteDAO.salvaUtenti(userList);


	}

}