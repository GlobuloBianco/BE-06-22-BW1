package entities;

import java.time.LocalDate;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Inheritance;
import javax.persistence.InheritanceType;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;

@Entity
@Inheritance(strategy = InheritanceType.SINGLE_TABLE)
public class Tessera {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private String numeroTessera;
	
	private boolean validita;
	private LocalDate dataErogazione;
	private LocalDate dataScadenza;
	
	@OneToOne
	@JoinColumn(name = "utente_id")
	private Utente utenteId;
	
	
	//getters & setters
	public String getNumeroTessera() {
		return numeroTessera;
	}
	public boolean isValidita() {
		return validita;
	}
	public void setValidita(boolean validita) {
		this.validita = validita;
	}
	public LocalDate getDataErogazione() {
		return dataErogazione;
	}
	public void setDataErogazione(LocalDate dataErogazione) {
		this.dataErogazione = dataErogazione;
	}
	public LocalDate getDataScadenza() {
		return dataScadenza;
	}
	public void setDataScadenza(LocalDate dataScadenza) {
		this.dataScadenza = dataScadenza;
	}
	public Utente getUtenteId() {
		return utenteId;
	}
	public void setUtenteId(Utente utenteId) {
		this.utenteId = utenteId;
	}
	
	
}
