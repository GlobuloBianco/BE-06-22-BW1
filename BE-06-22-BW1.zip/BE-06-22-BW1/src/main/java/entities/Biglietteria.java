package entities;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class Biglietteria {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int id;
	
	private tipologiaVendita vendita;
	private boolean valid;
	private int codiceUnivoco;
	private tipologiaBiglietto biglietto;

	
	
}

enum tipologiaVendita {
	RIVENDITORE, DISTRIBUTORE_AUTOMATICO;
}

enum tipologiaBiglietto {
	SINGOLO, SETTIMANALE, MENSILE 
}