package entities;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class Utente {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int id;
	
	private String username;
	private String dataNascita;
	private String indirizzo;
	
	private String tesseraId;
	
	//getters & setters
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public String getDataNascita() {
		return dataNascita;
	}
	public void setDataNascita(String dataNascita) {
		this.dataNascita = dataNascita;
	}
	public String getIndirizzo() {
		return indirizzo;
	}
	public void setIndirizzo(String indirizzo) {
		this.indirizzo = indirizzo;
	}
	public String getTessera_id() {
		return tesseraId;
	}
	public void setTessera_id(String tessera_id) {
		this.tesseraId = tessera_id;
	}
	
	@Override
	public String toString() {
		return "Utente [id=" + id + ", username=" + username + ", dataNascita=" + dataNascita + ", indirizzo="
				+ indirizzo + ", tessera_id=" + tesseraId + "]";
	}
	
	
}
