package entities;

public class ParcoMezzi {

}
