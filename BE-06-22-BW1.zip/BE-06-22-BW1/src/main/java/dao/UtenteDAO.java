package dao;

import java.util.ArrayList;

import entities.Tessera;
import entities.Utente;
import util.JpaUtil;

public class UtenteDAO extends JpaUtil {

	public static void save(Utente user) {
		try {
			t.begin();
			em.persist(user);
			t.commit();
		} catch (Exception x) {
			System.out.println("Ops! Qualcosa è andato storto... Riprova!");
		}
	}
	
	public static Utente creaUtente(String username, String data, String indirizzo, String tesId) {

		Utente u = new Utente();
		u.setUsername(username);
		u.setDataNascita(data);
		u.setIndirizzo(indirizzo);
		u.setTessera_id(tesId);
		
		return u;
	}
	
	public static void salvaUtenti(ArrayList<Utente> userList) {
		for (Utente u : userList) {
			save(u);
		}
	}
	
}
