package dao;

import java.time.LocalDate;
import java.util.ArrayList;

import entities.Tessera;
import entities.Utente;
import util.JpaUtil;

public class TesseraDAO extends JpaUtil {
	public static void save(Tessera te) {
		try {
			t.begin();
			em.persist(te);
			t.commit();
		} catch (Exception x) {
			System.out.println("Ops! Qualcosa è andato storto... Riprova!");
		}
	}
	
	public static Tessera creaTessera(String data, LocalDate dataInizio) {

		Tessera te = new Tessera();
		te.setValidita(true);
		te.setDataErogazione(dataInizio);
		te.setDataScadenza(dataInizio.plusYears(1));

		return te;
	}
	
	public static void salvaTessere(ArrayList<Tessera> tesList) {
		for (Tessera t : tesList) {
			save(t);
		}
	}
}