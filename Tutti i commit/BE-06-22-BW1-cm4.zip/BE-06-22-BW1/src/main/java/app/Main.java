package app;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Random;

import dao.BiglietteriaDAO;
import dao.TesseraDAO;
import dao.TitoloViaggioDAO;
import dao.UtenteDAO;
import entities.Biglietteria;
import entities.Tessera;
import entities.TitoloDiViaggio;
import entities.Biglietteria.StatoServizio;
import entities.Biglietteria.TipoEnte;
import entities.TitoloDiViaggio.TipoTitolo;
import entities.Utente;


public class Main {
	//----------------------------------------------------------------------!!
	//-------------------------switch per attivare--------------------------!!
						static boolean crea = true;
						
    //----------------------------------------------------------------------!!
    //----------------------------------------------------------------------!!
	static ArrayList<Utente> userList = new ArrayList<Utente>();
	static ArrayList<Tessera> tessereList = new ArrayList<Tessera>();
	static ArrayList<Biglietteria> biglietteriaList = new ArrayList<Biglietteria>();
	static ArrayList<TitoloDiViaggio> tViaggioList = new ArrayList<TitoloDiViaggio>();
	
	public static void main(String[] args) {
		if (crea) crea();

	}
	
	public static void crea() {
		//Utenti
		userList.add(UtenteDAO.creaUtente("Mario Rossi", "2002-02-21", "Via del Lago 8",generaNum(90000000,99999999)));
		
		//Tessere
		tessereList.add(TesseraDAO.caricaTessera(UtenteDAO.trovaUtenteByTessera(91015826).getNumeroTessera(), LocalDate.parse("2022-12-20")));
		
		//Biglietteria -Punto vendita
		biglietteriaList.add(BiglietteriaDAO.creaPuntoVendita(generaNum(10000,99999),StatoServizio.ATTIVO, TipoEnte.DISTRIBUTORE_AUTOMATICO));
		biglietteriaList.add(BiglietteriaDAO.creaPuntoVendita(generaNum(10000,99999),StatoServizio.ATTIVO, TipoEnte.RIVENDITORE_AUTORIZZATO));
		biglietteriaList.add(BiglietteriaDAO.creaPuntoVendita(generaNum(10000,99999),StatoServizio.ATTIVO, TipoEnte.RIVENDITORE_AUTORIZZATO));
		//Titoli Viaggio
		tViaggioList.add(TitoloViaggioDAO.acquistaTitoloViaggio(generaNum(1000000, 9999999), TipoTitolo.SETTIMANALE, BiglietteriaDAO.infoPuntoVenditaByID(73493)));
		tViaggioList.add(TitoloViaggioDAO.acquistaTitoloViaggio(generaNum(1000000, 9999999), TipoTitolo.BIGLIETTO, BiglietteriaDAO.infoPuntoVenditaByID(73493)));
		//salvataggi
		UtenteDAO.salvaUtenti(userList);
		TesseraDAO.salvaTessere(tessereList);
		TitoloViaggioDAO.salvaTitoliDiViaggio(tViaggioList);
		BiglietteriaDAO.salvaBiglietteria(biglietteriaList);

	}

	public static int generaNum(int minN, int maxN) {
		HashSet<Integer> init = new HashSet<>();
		Random r = new Random();
		int min = minN;
		int max = maxN;
        int n = 0;
        
        do {
            n = min + (int)(r.nextDouble()*(max - min));
        } while (init.contains(n));
        
        init.add(n);
        return n;
	}
}