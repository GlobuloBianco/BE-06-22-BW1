package dao;

import java.time.LocalDate;
import java.util.ArrayList;

import javax.persistence.NoResultException;

import entities.Tessera;
import entities.TitoloDiViaggio;
import util.JpaUtil;

public class TesseraDAO extends JpaUtil {
	public static void save(Tessera te) {
		try {
			t.begin();
			em.persist(te);
			t.commit();
		} catch (Exception x) {
			System.out.println("Ops! Qualcosa è andato storto... Riprova!");
		}
	}
	
	public static Tessera caricaTessera(int numTessera, LocalDate data) {
		Tessera t = new Tessera();
		t.setTessera(numTessera);
		t.setDataInizio(data);
		t.setDataScadenza(data.plusYears(1));
		System.out.println("tessera creata con successo");
		return t;
	}
	
	/*
	public static Tessera controllaAbbonamento(int numT) {
		try { 						  //SELECT * FROM public.tessera WHERE id = 91376784
	    	Tessera t = em.createQuery("SELECT t FROM Tessera t WHERE t.tessera = :tes", Tessera.class)
	                .setParameter("tes", numT)
	                .getSingleResult();
	        return t;
		} catch (NoResultException x) {
	        System.out.println("Tessera non trovata!");
	        return null;
	    }
	} */
	
	public static void salvaTessere(ArrayList<Tessera> tList) {
		try {
			for (Tessera t : tList) {
				save(t);
			}
			System.out.println("Tessere salvate con successo!");
		} catch (Exception e) {
			System.out.println("Errore nel salvataggio.");
		}
	}
}
