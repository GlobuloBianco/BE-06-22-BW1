package entities;

import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToOne;

@Entity
public class TitoloDiViaggio {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int id;
	
	private int numeroBiglietto;
	
	@Enumerated(EnumType.STRING)
    private TipoTitolo tipoTitolo;
	@OneToOne
	private Biglietteria luogoEmissione;
	
	//enum
    public enum TipoTitolo {
    	BIGLIETTO, SETTIMANALE, MENSILE
    }

    //getter setter

	public int getNumeroBiglietto() {
		return numeroBiglietto;
	}

	public void setNumeroBiglietto(int numeroBiglietto) {
		this.numeroBiglietto = numeroBiglietto;
	}

	public TipoTitolo getTipoTitolo() {
		return tipoTitolo;
	}

	public void setTipoTitolo(TipoTitolo tipoTitolo) {
		this.tipoTitolo = tipoTitolo;
	}

	public Biglietteria getLuogoEmissione() {
		return luogoEmissione;
	}

	public void setLuogoEmissione(Biglietteria luogoEmissione) {
		this.luogoEmissione = luogoEmissione;
	}
	

}
