package it.gruppo6.dao;

import java.util.List;
import java.util.Scanner;

import javax.persistence.EntityManager;

import it.gruppo6.app.Main;
import it.gruppo6.entities.TitoloDiViaggio;
import it.gruppo6.entities.Tratte;
import it.gruppo6.entities.Veicoli;
import it.gruppo6.entities.Veicoli.StatoManutenzione;
import it.gruppo6.util.JpaUtil;

public class TrattaDAO extends JpaUtil {
	public static void save(Tratte tr) {
		try {
			t.begin();
			em.persist(tr);
			t.commit();
		} catch (Exception x) {
			System.out.println("Ops! Qualcosa è andato storto nel salvataggio della tratta.");
		}
	}
	
	// AGGIUNGO UN VEICOLO A UNA TRATTA
	public static void aggiungiVeicoloATratta() {
			Scanner myObj = new Scanner(System.in);
			try {
				EntityManager em = JpaUtil.getEntityManagerFactory().createEntityManager();
				em.getTransaction().begin();
				// INSERISCO L'ID DELLA TRATTA CHE VOGLIO
				System.out.println("Inserire l'id della tratta da assocciare al veicolo: ");
				long id_tratta;
				long id_veicolo;
				while (true) {
					try {
						id_tratta = Long.parseLong(myObj.nextLine());
						Tratte tratta = em.find(Tratte.class, id_tratta);
						if (tratta == null) {
							System.err.println("Tratta con id " + id_tratta + " inesistente");
							System.out.println("Inserire l'id della tratta: ");
							continue;
						}
						System.out.println("Inserire id veicolo: ");
						id_veicolo = Long.parseLong(myObj.nextLine());
						Veicoli veicolo = em.find(Veicoli.class, id_veicolo);
						if (veicolo == null) {
							System.err.println("Veicolo con id " + id_veicolo + " inesistente");
							System.out.println("Inserire l'id della tratta: ");
							continue;
						}
						if (veicolo.getTratta() != null) {
							System.err.println("Il veicolo con id " + id_veicolo + " è gia assegnato ad un'altra tratta");
							System.out.println("Inserire l'id della tratta: ");
							continue;
						}
						if (tratta.getVeicoli().contains(veicolo)) {
							System.err.println(
									"Il veicolo con id " + id_veicolo + " è gia assegnato alla tratta " + id_tratta);
							System.out.println("Inserire id tratta: ");
							continue;
						}
						tratta.getVeicoli().add(veicolo);
						veicolo.setTratta(tratta);
						System.out.println("Aggiunto correttamente il veicolo con l'id: " + id_veicolo
								+ " alla tratta: " + tratta.getPuntoPartenza() + "-" + tratta.getArrivo());
						em.merge(tratta);
						em.merge(veicolo);
						em.getTransaction().commit();
						em.close();
						Main.opzioniParcoMezzi();
						break;
					} catch (NumberFormatException e) {
						System.out.println("Devi inserire un numero.");
						aggiungiVeicoloATratta();
					}
				}
				// INSERISCO L'ID DEL VEICOLO
				// AGGIUNGO IL VEICOLO ALLA TRATTA
			} catch (Exception e) {
				t.rollback();
				System.out.println("Errore.");
				aggiungiVeicoloATratta();
				throw e;
			}
	}
	
	public static void eseguiTratta() {
		Scanner myObj = new Scanner(System.in);
		try {
			t.begin();
			System.out.println("Quale tratta vuoi eseguire? ");
			System.out.println("Tratte Disponibili: ");
			List<Tratte> tratte = em.createQuery("SELECT t from Tratte t JOIN t.veicoli v WHERE v.stato = 'IN_SERVIZIO'", Tratte.class).getResultList();
			for (Tratte tratta : tratte) {
				System.out.println("---------------------------------------------------------------");
				System.out.println("Id tratta: " + tratta.getId());
				System.out.println("Partenza: " + tratta.getPuntoPartenza());
				System.out.println("Arrivo: " + tratta.getArrivo());
				System.out.println("Tempo percorrenza: " + tratta.getTempoMedio() + " ore");
				System.out.println("Tipologia veicolo : " + tratta.getVeicoli().get(0).getTipoVeicolo());
				System.out.println("Capacita veicolo : " + tratta.getVeicoli().get(0).getCapacita());
				System.out.println("Id veicolo: " + tratta.getVeicoli().get(0).getId());
				System.out.println("Stato veicolo: " + tratta.getVeicoli().get(0).getStato());
			}
			// LA QUERY SELEZIONA TUTTI LE TRATTE CON I VEICOLO IL CUI STATO è MANUTENZIONE
			List<Tratte> tratte2 = em
					.createQuery("SELECT t from Tratte t JOIN t.veicoli v WHERE v.stato = 'MANUTENZIONE'", Tratte.class)
					.getResultList();
			System.out.println("---------------------------------------------------------------");
			System.out.println("TRATTE NON DISPONIBILI");
			System.out.println("---------------------------------------------------------------");
			if (tratte2.isEmpty()) {
				System.out.println("[i] Tutte le tratte al momento sono disponibili. \n");
			}
			for (Tratte tratta : tratte2) {
				System.out.println("Id tratta: " + tratta.getId());
				System.out.println("Partenza: " + tratta.getPuntoPartenza());
				System.out.println("Arrivo: " + tratta.getArrivo());
				System.out.println("Id veicolo: " + tratta.getVeicoli().get(0).getId());
				System.out.println("Stato veicolo: " + tratta.getVeicoli().get(1).getStato());
				System.out.println("---------------------------------------------------------------");
			}
			long id_tratta = 0;
			boolean invalidInput = true;
			Tratte tratta = null;
			Veicoli veicolo = null;
			while (invalidInput) {
			    try {
			        System.out.println("Inserisci ID della tratta:");
			        id_tratta = Long.parseLong(myObj.nextLine());
			        invalidInput = false;
			        tratta = em.find(Tratte.class, id_tratta);
			        if (tratta == null) {
			            System.out.println("Tratta non trovata, reinserire l'ID:");
			            invalidInput = true;
			            continue;
			        }
			        if (tratta.getVeicoli().isEmpty()) {
			            System.out.println("Nessun veicolo assegnato a questa tratta");
			            invalidInput = true;
			            continue;
			        }
			        veicolo = tratta.getVeicoli().get(0);
			        if (veicolo.getStato().equals(StatoManutenzione.MANUTENZIONE)) {
			            System.out.println("Il veicolo assegnato a questa tratta è in manutenzione, seleziona un'altra tratta");
			            invalidInput = true;
			            continue;
			        }
			    } catch (NumberFormatException e) {
			        System.err.println("Devi inserire un numero");
			        invalidInput = true;
			    }
			}
	        tratta.setNumeroVolteTrattoPercorso(tratta.getNumeroVolteTrattoPercorso() + 1);
	        String input = "";
		    	try {
		    		System.out.println("Inserire il numero del biglietto da vidimare oppure scrivi (0) per tornare indietro.");
		    		input = myObj.nextLine();
		    		if (input.equals("0")) {
		    			Main.opzioniParcoMezzi();
		    		}
		    		if (input != "0") {
		    			t.begin();
		    			TitoloDiViaggio biglietto = TitoloViaggioDAO.getBigliettoById(input);
		    			biglietto.setConvalidato(true);
		    			veicolo.setBigliettiVidimati(veicolo.getBigliettiVidimati() + 1);
		    			System.out.println("Il veicolo ha vidimato: " + veicolo.getBigliettiVidimati() + " biglietti");
		    			em.merge(veicolo);
		    			em.merge(biglietto);
		    			t.commit();
		    		}
		    	} catch (Exception e) {
		    		System.err.println("Bisogna inserire un numero");
		    	}
		    	em.merge(tratta);
			    em.getTransaction().commit();
			    em.close();
		}catch (Exception e) {
			t.rollback();
			System.out.println("Sbagliato");
			throw e;
		}
		System.out.println("Tratta eseguita correttamente");
		eseguiTratta();
	}
}
