package dao;

import java.time.LocalDate;

import entities.Tessera;
import util.JpaUtil;

public class TesseraDAO extends JpaUtil {
	public static void save(Tessera te) {
		try {
			t.begin();
			em.persist(te);
			t.commit();
		} catch (Exception x) {
			System.out.println("Ops! Qualcosa è andato storto... Riprova!");
		}
	}
	
	public static Tessera caricaTessera(int numTessera, LocalDate data) {
		Tessera t = new Tessera();
		t.setId(numTessera);
		t.setDataInizio(data);
		t.setValidita(true);
		t.setDataScadenza(data.plusYears(1));
		System.out.println("tessera creata con successo");
		return t;
	}
	
    
    public boolean verificaValiditaAbbonamento(int numeroTessera) {
        
        return true;
    }
}
