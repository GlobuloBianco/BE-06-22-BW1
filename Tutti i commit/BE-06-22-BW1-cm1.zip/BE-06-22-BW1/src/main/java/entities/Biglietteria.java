package entities;

import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table( name = "biglietteria")
public class Biglietteria {

    @Id
    private int id;

    @Enumerated(EnumType.STRING)
    private TipoEnte tipoEnte;

    @Enumerated(EnumType.STRING)
    private StatoServizio statoServizio;
    


    private int qtyEmessa;
    

    // enums
    public enum TipoEnte {
        DISTRIBUTORE_AUTOMATICO, RIVENDITORE_AUTORIZZATO
    }

    public enum StatoServizio {
        ATTIVO, FUORI_SERVIZIO
    }
    
    public enum TipoTitolo {
    	BIGLIETTO, SETTIMANALE, MENSILE
    }
    
    //getter setter
    public TipoEnte getTipoEnte() {
		return tipoEnte;
	}

	public void setTipoEnte(TipoEnte tipoEnte) {
		this.tipoEnte = tipoEnte;
	}

	public StatoServizio getStatoServizio() {
		return statoServizio;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public void setStatoServizio(StatoServizio statoServizio) {
		this.statoServizio = statoServizio;
	}

	public int getQtyEmessa() {
		return qtyEmessa;
	}

	public void setQtyEmessa(int qtyEmessa) {
		this.qtyEmessa = qtyEmessa;
	}

    //da fare: bisogna dirgli che settimanali e mensili devono essere collegati al numero tessera senno non possono essere emessi, il biglietto puo essere emesso sempre e bisogna identificare se il distributore automatico o il rivenditore e sopratutto generare un codice univoco del titolo di viaggio
}
