package app;

import javax.persistence.EnumType;
import javax.persistence.Enumerated;

import entities.Biglietteria.TipoTitolo;

public class salvataggioDiDati {
/*     @Enumerated(EnumType.STRING)
    private TipoTitolo tipoTitolo;
    
    *
    *
    *
	public TipoTitolo getTipoTitolo() {
		return tipoTitolo;
	}

	public void setTipoTitolo(TipoTitolo tipoTitolo) {
		this.tipoTitolo = tipoTitolo;
	}
    *
    */
	
	
}
