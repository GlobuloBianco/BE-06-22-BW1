package dao;

import javax.persistence.NoResultException;

import entities.Biglietteria;
import entities.Tessera;
import entities.Tessera.TipoTitolo;
import util.JpaUtil;

public class TitoloViaggioDAO extends JpaUtil{
	
	public static Tessera acquistoAbbonamento(int numT, TipoTitolo tipo) {
		try { 						  //SELECT * FROM public.tessera WHERE id = 91376784
	    	Tessera t = em.createQuery("SELECT t FROM Tessera t WHERE t.id = :id", Tessera.class)
	                .setParameter("id", numT)
	                .getSingleResult();
	        return t;
		} catch (NoResultException x) {
	        System.out.println("Tessera non trovata!");
	        return null;
	    }
	}
}
