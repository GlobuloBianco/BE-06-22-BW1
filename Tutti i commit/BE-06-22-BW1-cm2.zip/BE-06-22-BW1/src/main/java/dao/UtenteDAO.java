package dao;

import entities.Utente;
import util.JpaUtil;


public class UtenteDAO extends JpaUtil {
	public static void save(Utente user) {
		try {
			t.begin();
			em.persist(user);
			t.commit();
		} catch (Exception x) {
			System.out.println("Ops! Qualcosa è andato storto... Riprova!");
		}
	}
	
	public static Utente creaUtente(String username, String data, String indirizzo, int num) {

		Utente u = new Utente();
		u.setUsername(username);
		u.setDataNascita(data);
		u.setIndirizzo(indirizzo);
		u.setNumeroTessera(num);
		return u;
	}
	
	
}
