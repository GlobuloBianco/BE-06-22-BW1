package dao;

import entities.Biglietteria;
import entities.Biglietteria.StatoServizio;
import entities.Biglietteria.TipoEnte;
import util.JpaUtil;

public class BiglietteriaDAO extends JpaUtil {
	public static void save(Biglietteria b) {
		try {
			t.begin();
			em.persist(b);
			t.commit();
		} catch (Exception x) {
			System.out.println("Ops! Qualcosa è andato storto... Riprova!");
		}
	}
	
	public static Biglietteria creaPuntoVendita(int id, StatoServizio ss, TipoEnte te) {

		Biglietteria b = new Biglietteria();
		b.setId(id);
		b.setQtyEmessa(0);
		b.setStatoServizio(ss);
		b.setTipoEnte(te);
		
		return b;
	}
}
