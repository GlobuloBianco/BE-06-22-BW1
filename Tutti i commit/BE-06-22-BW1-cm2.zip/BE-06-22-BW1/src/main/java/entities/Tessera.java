package entities;
import java.time.LocalDate;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.Id;

@Entity
public class Tessera {
	@Id
	private int id;
	
	private LocalDate dataInizio;
	private LocalDate dataScadenza;
	private boolean validita;
	
	@Enumerated(EnumType.STRING)
    private TipoTitolo tipoTitolo;
	
	//enum
    public enum TipoTitolo {
    	BIGLIETTO, SETTIMANALE, MENSILE
    }
	
    //getter setter
    public TipoTitolo getTipoTitolo() {
		return tipoTitolo;
	}

	public void setTipoTitolo(TipoTitolo tipoTitolo) {
		this.tipoTitolo = tipoTitolo;
	}
	
	public boolean isValidita() {
		return validita;
	}

	public void setValidita(boolean validita) {
		this.validita = validita;
	}

	public LocalDate getDataInizio() {
		return dataInizio;
	}

	public void setDataInizio(LocalDate dataInizio) {
		this.dataInizio = dataInizio;
	}

	public int getId() {
		return id;
	}
	
	public void setDataScadenza(LocalDate dataScadenza) {
		this.dataScadenza = dataScadenza;
	}

	public void setId(int id) {
		this.id = id;
	}

	public LocalDate getDataScadenza() {
		return dataScadenza;
	}

	@Override
	public String toString() {
		return "Tessera [ id= " + id + " | dataInizio= " + dataInizio + " | dataScadenza= " + dataScadenza + " | validita= "
				+ validita + " | tipoTitolo= " + tipoTitolo + " ]";
	}
	
	
}
