package app;

import javax.persistence.EnumType;
import javax.persistence.Enumerated;

public class salvataggioDiDati {
/*     
    
    *    

    *
    *
	
    *
    */
	
	
}
