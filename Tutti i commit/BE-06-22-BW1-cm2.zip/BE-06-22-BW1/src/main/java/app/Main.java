package app;

import java.time.LocalDate;
import java.util.HashSet;
import java.util.Random;

import dao.BiglietteriaDAO;
import dao.TesseraDAO;
import dao.TitoloViaggioDAO;
import dao.UtenteDAO;
import entities.Biglietteria;
import entities.Biglietteria.StatoServizio;
import entities.Biglietteria.TipoEnte;
import entities.Tessera.TipoTitolo;
import entities.Utente;


public class Main {

	
	public static void main(String[] args) {
		/*Utente u1 = UtenteDAO.creaUtente("Mario Rossi", "2002-02-21", "Via del Lago 8",generaNum(90000000,99999999));

		UtenteDAO.save(u1);
		
		TesseraDAO.save(TesseraDAO.caricaTessera(u1.getNumeroTessera(), LocalDate.parse("2022-12-20")));
		

		Biglietteria b1 = BiglietteriaDAO.creaPuntoVendita(generaNum(10000,99999),StatoServizio.ATTIVO, TipoEnte.DISTRIBUTORE_AUTOMATICO);
		BiglietteriaDAO.save(b1);

		Biglietteria b2 = BiglietteriaDAO.creaPuntoVendita(generaNum(10000,99999),StatoServizio.ATTIVO, TipoEnte.RIVENDITORE_AUTORIZZATO);
		BiglietteriaDAO.save(b2); */
		
		System.out.println(TitoloViaggioDAO.acquistoAbbonamento(91818767, TipoTitolo.MENSILE).toString());

	}

	public static int generaNum(int minN, int maxN) {
		HashSet<Integer> init = new HashSet<>();
		Random r = new Random();
		int min = minN;
		int max = maxN;
        int n = 0;
        
        do {
            n = min + (int)(r.nextDouble()*(max - min));
        } while (init.contains(n));
        
        init.add(n);
        return n;
	}
}