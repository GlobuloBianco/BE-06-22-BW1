package app;

import java.util.Scanner;
import java.util.stream.Stream;

import dao.BiglietteriaDAO;
import util.Methods;

public class Main {

	static Scanner scan = new Scanner(System.in);

	public static void main(String[] args) {
		Decorazioni.titolo();

		start();
		scan.close();
	}
	

	//----------------------------------------Apertura scanner----------------------------------------//

	public static void start() {

		int scelta;

		while (true) {
			System.out.println("Benvenuto,\nseleziona tra le seguenti opzioni per continuare: ");
			System.out.println("-----------------------------------------------------");
			System.out.println("| \033[32m(1) Utente \033[37m| \033[31m(2) Gestore \033[37m| (0) Termina esecuzione |");
			System.out.println("-----------------------------------------------------");

			if (scan.hasNextInt()) {
				scelta = scan.nextInt();
				if (scelta == 1 || scelta == 2 || scelta == 0) {
					break;
				} else {
					System.out.println("Scelta non valida. Riprovare.");
				}
			} else { // se scelgono un decimale
				System.out.println("Inserire un numero intero valido.");
				scan.next(); // per pulire l'input
			}
		}

		switch (scelta) {
		case 1:
			System.out.println("Hai scelto opzione Utente");
			opzioniUtente();
			break;
		case 2:
			System.out.println("Hai scelto opzione Gestore");
			opzioniGestore();
			break;
		case 0:
			System.out.println("Esecuzione del programma terminata.");
			break;
		}
	}

	//----------------------------------------Interfaccia Utente----------------------------------------//

	public static void opzioniUtente() {
		int sceltaU;

		while (true) {
			System.out.println("Seleziona tra le seguenti opzioni per continuare: \n ");

			System.out.println(
					"(1) Acquista un biglietto \n(2) Registrati \n(3) Acquista un abbonamento \n(4) Controlla la tua tessera\n(5) Indietro");

			if (scan.hasNextInt()) {
				sceltaU = scan.nextInt();
				if (sceltaU >= 1 && sceltaU <= 5) {
					break;
				} else {
					System.out.println("Scelta non valida. Riprovare.");
				}
			} else {
				System.out.println("Inserire un numero intero valido.");
				scan.next();
			}
		}
		switch (sceltaU) {
		case 1:
			// acquista biglietto
			Methods.compraBiglietto();
			break;

		case 2:
			// resgistra nuova tessera
			Methods.creaUtente();
			break;

		case 3:
			// acquista abbonamento
			Methods.compraAbbonamento();
			break;

		case 4:
			// controlla la tua tessera
			Methods.controlloTesseraUtente();
			break;

		case 5:
			// indietro
			start();
			break;
		}
	}

	
	//----------------------------------------Interfaccia Gestore----------------------------------------//

	public static void opzioniGestore() {
		int sceltaG;

		while (true) {
			System.out.println("Seleziona tra le seguenti opzioni per continuare: \n ");

			System.out.println(
					"(1) Aggiungi punto vendita \n(2) Modifica stato punto vendita \n(3) Controlla tessera utente \n(4) Controlla il totale dei titoli di viaggio emessi da tutti i punti vendita \n(5) Controlla titoli di viaggio emessi da un punto vendita \n(6) Indietro");

			if (scan.hasNextInt()) {
				sceltaG = scan.nextInt();
				if (sceltaG >= 1 && sceltaG <= 6) {
					break;
				} else {
					System.out.println("Scelta non valida. Riprovare.");
				}
			} else { // se scelgono un decimale
				System.out.println("Inserire un numero intero valido.");
				scan.next(); // per pulire l'input
			}
		}

		switch (sceltaG) {
		case 1:
			// aggiungi punto vendita
			Methods.creaPuntoVendita();
			break;
		case 2:
			// cambio stato attivita punto vendita
			Methods.modificaPV();
			break;

		case 3:
			// controlla per tessera utente
			Methods.controlloTessera();
			break;

		case 4:
			// controlla il totale di titoli di viaggio emessi
			BiglietteriaDAO.totaleQtyEmessa();
			opzioniGestore();
			break;

		case 5:
			// controllo titoli viaggio emessi da un punto vendita
			Methods.controllaEmissioniPv();
			opzioniGestore();
			break;
		case 6:
			// indietro
			start();
			break;
		}
	}
}