package app;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Random;
import java.util.Scanner;

import javax.persistence.NoResultException;

import dao.BiglietteriaDAO;
import dao.TesseraDAO;
import dao.TitoloViaggioDAO;
import dao.UtenteDAO;
import entities.Biglietteria;
import entities.Tessera;
import entities.TitoloDiViaggio;
import entities.Biglietteria.StatoServizio;
import entities.Biglietteria.TipoEnte;
import entities.TitoloDiViaggio.TipoTitolo;
import entities.Utente;

public class Main {

	static ArrayList<Utente> userList = new ArrayList<Utente>();
	static ArrayList<Tessera> tessereList = new ArrayList<Tessera>();
	static ArrayList<Biglietteria> biglietteriaList = new ArrayList<Biglietteria>();
	static ArrayList<TitoloDiViaggio> tViaggioList = new ArrayList<TitoloDiViaggio>();
	static Scanner scan = new Scanner(System.in);

	public static void main(String[] args) {

		/*
		 * if (crea) crea(); if (compraTitoliViaggio) compraTV(); //validità tessera e
		 * abbonamenti if (getInfo)
		 * System.out.println(TesseraDAO.getInfoByIdTessera("UT920308")); //crea totale
		 * di titoli di viaggio emessi in tutti i punti vendita if (getTotaleEmessi)
		 * BiglietteriaDAO.totaleQtyEmessa();
		 */

		start();
		scan.close();

	}

	// ---------------------------------------------APERTURA SCANNER

	public static void start() {

		int scelta;

		while (true) {
			System.out.println("Benvenuto,\nseleziona tra le seguenti opzioni per continuare: ");
			System.out.println("-----------------------------------------------------");
			System.out.println("| \033[32m(1) Utente \033[37m| \033[31m(2) Gestore \033[37m| (0) Termina esecuzione |");
			System.out.println("-----------------------------------------------------");

			if (scan.hasNextInt()) {
				scelta = scan.nextInt();
				if (scelta == 1 || scelta == 2 || scelta == 0) {
					break;
				} else {
					System.out.println("Scelta non valida. Riprovare.");
				}
			} else { // se scelgono un decimale
				System.out.println("Inserire un numero intero valido.");
				scan.next(); // per pulire l'input
			}
		}

		switch (scelta) {
		case 1:
			System.out.println("Hai scelto opzione Utente");
			opzioniUtente();
			break;
		case 2:
			System.out.println("Hai scelto opzione Gestore");
			opzioniGestore();
			break;
		case 0:
			System.out.println("Esecuzione del programma terminata.");
			break;
		}
	}

	// -----------------------------------------MENU UTENTE

	private static void opzioniUtente() {
		int sceltaU;

		while (true) {
			System.out.println("Seleziona tra le seguenti opzioni per continuare: \n ");

			System.out.println(
					"(1) Acquista un biglietto \n(2) Registrati \n(3) Acquista un abbonamento \n(4) Controlla la tua tessera\n(5) Indietro");

			if (scan.hasNextInt()) {
				sceltaU = scan.nextInt();
				if (sceltaU >= 1 && sceltaU <= 5) {
					break;
				} else {
					System.out.println("Scelta non valida. Riprovare.");
				}
			} else {
				System.out.println("Inserire un numero intero valido.");
				scan.next();
			}
		}
		switch (sceltaU) {
		case 1:
			// acquista biglietto
			compraBiglietto();
			break;

		case 2:
			// resgistra nuova tessera
			creaUtente();
			break;

		case 3:
			// acquista abbonamento
			compraAbbonamento();
			break;

		case 4:
			// controlla la tua tessera
			controlloTesseraUtente();
			break;

		case 5:
			// indietro
			start();
			break;
		}
	}

	public static void compraBiglietto() {
		Scanner s = new Scanner(System.in);
		System.out.println("Inserisci il codice del punto vendita: ");
		String sceltaP = s.nextLine();
		Biglietteria result = BiglietteriaDAO.infoPuntoVenditaByID(sceltaP);
		TitoloDiViaggio biglietto = TitoloViaggioDAO.acquistaTitoloViaggio(generaNum("B"), null, TipoTitolo.BIGLIETTO,
				result);
		TitoloViaggioDAO.save(biglietto);
		System.out.println("Dettagli biglietto acquistato: \n" + biglietto.toString());
		opzioniUtente();
	}

	private static void creaUtente() {
		// public static Utente creaUtente(String username, String data, String
		// indirizzo, Tessera tessera)
		Scanner r = new Scanner(System.in);
		System.out.println("Inserisci il tuo nome e cognome: ");
		String sceltaNome = r.nextLine();
		System.out.println("Inserisci la tua data di nascita in formato YYYY-MM-DD: ");
		String sceltaData = r.nextLine();
		System.out.println("Inserisci il tuo indirizzo: ");
		String sceltaAdd = r.nextLine();

		Tessera tessera = TesseraDAO.creaTessera(generaNum("UT"), LocalDate.now());
		TesseraDAO.save(tessera);
		UtenteDAO.save(UtenteDAO.creaUtente(sceltaNome, sceltaData, sceltaAdd, tessera));
		System.out.println("Ecco il tuo nuovo numero di tessera: " + tessera.getId());
		System.out.println("Ora puoi acquistare abbonamenti settimanali e mensili!");
		opzioniUtente();

	}

	private static void compraAbbonamento() {

	
		Scanner y = new Scanner(System.in);
		boolean flag = true;
		while (flag) {
			System.out.println("Inserisci il numero della tua tessera per continuare: \n ");
			String tesseraId = y.nextLine();

			try {
				Tessera tessera = TesseraDAO.getInfoByIdTesseraAbbonamento(tesseraId);
				System.out.println("Codice tessera: " + tessera.getId() + "\nAbbonamento: " + tessera.getTipologia());
				System.out.println("Inserisci il codice del punto vendita: ");
				String sceltaPv = y.nextLine();
				Biglietteria resultPv = BiglietteriaDAO.infoPuntoVenditaByID(sceltaPv);
				System.out.println("Digita per acquistare: (1) Abbonamento settimanale - (2) Abbonamento mensile");
				String sceltaAbb = "";
			
				if (y.hasNextLine()) {
					sceltaAbb = y.nextLine();
					if (sceltaAbb == "1" || sceltaAbb == "2") {
						break;
					} else {
						System.out.println("Scelta non valida. Riprovare.");
					}
				} else {
					System.out.println("Inserire un numero intero valido.");
					y.next();
				}

				switch (sceltaAbb) {
				case "1":
					// acquista settimanale
					TitoloDiViaggio s = TitoloViaggioDAO.acquistaTitoloViaggio(generaNum("S"), tessera, TipoTitolo.SETTIMANALE, resultPv);
					TitoloViaggioDAO.save(s);
					break;

				case "2":
					// racquista mensile
					TitoloDiViaggio m = TitoloViaggioDAO.acquistaTitoloViaggio(generaNum("M"), tessera, TipoTitolo.MENSILE, resultPv);

					TitoloViaggioDAO.save(m);
					break;
				}
				flag = false;

			} catch (NoResultException e) {
				System.out.println("La tessera non è stata trovata!");
				opzioniUtente();

			}
		}

	}



	public static void controlloTesseraUtente() {
		Scanner ut = new Scanner(System.in);
		System.out.println("Inserisci il tuo numero di tessera da controllare: ");
		String sceltaT;
		sceltaT = ut.nextLine();

		TesseraDAO.getInfoByIdTessera(sceltaT);
		opzioniUtente();

	}

//-----------------------------------------MENU GESTORE

	public static void opzioniGestore() {
		int sceltaG;

		while (true) {
			System.out.println("Seleziona tra le seguenti opzioni per continuare: \n ");

			System.out.println(
					"(1) Aggiungi punto vendita \n(2) Modifica stato punto vendita \n(3) Controlla tessera utente \n(4) Controlla il totale dei titoli di viaggio emessi da tutti i punti vendita \n(5) Controlla titoli di viaggio emessi da un punto vendita \n(6) Indietro");

			if (scan.hasNextInt()) {
				sceltaG = scan.nextInt();
				if (sceltaG >= 1 && sceltaG <= 6) {
					break;
				} else {
					System.out.println("Scelta non valida. Riprovare.");
				}
			} else { // se scelgono un decimale
				System.out.println("Inserire un numero intero valido.");
				scan.next(); // per pulire l'input
			}
		}

		switch (sceltaG) {
		case 1:
			// aggiungi punto vendita
			creaPuntoVendita();
			break;
		case 2:
			// cambio stato attivita punto vendita
			modificaPV();
			break;

		case 3:
			// controlla per tessera utente
			controlloTessera();
			break;

		case 4:
			// controlla il totale di titoli di viaggio emessi
			BiglietteriaDAO.totaleQtyEmessa();
			opzioniGestore();
			break;

		case 5:
			// controllo titoli viaggio emessi da un punto vendita
			controllaEmissioniPv();
			opzioniGestore();
			break;
		case 6:
			// indietro
			start();
			break;
		}
	}

	public static void controlloTessera() {
		Scanner in = new Scanner(System.in);
		System.out.println("Inserisci il numero di tessera da controllare: ");
		String sceltaT;
		sceltaT = in.nextLine();

		TesseraDAO.getInfoByIdTessera(sceltaT);
		opzioniGestore();

	}

	public static void creaPuntoVendita() {
		Scanner pv = new Scanner(System.in);
		System.out.println(
				"Scegli (1) per creare Rivenditore Autorizzato\nScegli (2) per creare Distributore Automatico");
		String sceltaTipo = pv.nextLine();
		while (!sceltaTipo.equals("1") && !sceltaTipo.equals("2")) {
			System.out.println("Scelta non valida. Riprovare.");
			sceltaTipo = pv.nextLine();
		}
		System.out.println("Inserisci il codice identificativo del nuovo punto vendita: ");
		String sceltaId = pv.nextLine();
		switch (sceltaTipo) {
		case "1":
			BiglietteriaDAO.save(BiglietteriaDAO.creaPuntoVendita(sceltaId, TipoEnte.RIVENDITORE_AUTORIZZATO));
			opzioniGestore();
			break;
		case "2":
			BiglietteriaDAO.save(BiglietteriaDAO.creaPuntoVendita(sceltaId, TipoEnte.DISTRIBUTORE_AUTOMATICO));
			opzioniGestore();
			break;
		}
	}

	public static void modificaPV() {

		Scanner mpv = new Scanner(System.in);
		System.out.println("Inserisci il codice del punto vendita da modificare");
		String sceltaId = mpv.nextLine();
		BiglietteriaDAO.infoPuntoVenditaByIDStato(sceltaId);
		System.out.println("Digita (1) per attivare il punto vendita\nDigita (2) per disattivare il punto vendita");
		String sceltax = mpv.nextLine();
		while (!sceltax.equals("1") && !sceltax.equals("2")) {
			System.out.println("Scelta non valida. Riprovare.");
			sceltax = mpv.nextLine();
		}
		switch (sceltax) {
		case "1":
			BiglietteriaDAO.cambiaStato(sceltaId, StatoServizio.ATTIVO);
			opzioniGestore();
			break;
		case "2":
			BiglietteriaDAO.cambiaStato(sceltaId, StatoServizio.FUORI_SERVIZIO);
			opzioniGestore();
			break;
		}
	}

	public static void controllaEmissioniPv() {
		Scanner xxx = new Scanner(System.in);
		System.out.println("Inserisci il codice identificativo del punto vendita");
		String sceltaId = xxx.nextLine();
		System.out.println("Codice identificativo: " + BiglietteriaDAO.infoPuntoVenditaByID(sceltaId).getId()
				+ "\nQuantità emessa: " + BiglietteriaDAO.infoPuntoVenditaByID(sceltaId).getQtyEmessa());

	}

	// ----------------------------Creazioni----------------------------//
	public static void crea() {
		// Tessere
		tessereList.add(TesseraDAO.creaTessera(generaNum("UT"), LocalDate.parse("2022-12-20")));
		tessereList.add(TesseraDAO.creaTessera(generaNum("UT"), LocalDate.parse("2022-01-12")));
		tessereList.add(TesseraDAO.creaTessera(generaNum("UT"), LocalDate.parse("2022-05-26")));
		TesseraDAO.salvaTessere(tessereList);

		// Utenti
		userList.add(UtenteDAO.creaUtente("Mario Rossi", "2002-02-21", "Via del Lago 8", tessereList.get(0)));
		userList.add(UtenteDAO.creaUtente("Luigi Verdi", "2000-12-11", "Via Castelli 2", tessereList.get(1)));
		userList.add(UtenteDAO.creaUtente("Peach Rosi", "1999-06-01", "Via Monti 12", tessereList.get(2)));
		UtenteDAO.salvaUtenti(userList);

		// Biglietteria -Punto vendita
		// biglietteriaList.add(BiglietteriaDAO.creaPuntoVendita("AUT-001",StatoServizio.FUORI_SERVIZIO,
		// TipoEnte.DISTRIBUTORE_AUTOMATICO));
		// biglietteriaList.add(BiglietteriaDAO.creaPuntoVendita("RIV-001",StatoServizio.ATTIVO,
		// TipoEnte.RIVENDITORE_AUTORIZZATO));
		// biglietteriaList.add(BiglietteriaDAO.creaPuntoVendita("RIV-002",StatoServizio.ATTIVO,
		// TipoEnte.RIVENDITORE_AUTORIZZATO));
		// BiglietteriaDAO.salvaBiglietteria(biglietteriaList);
	}

	// ----------------------------Compra Titoli di
	// Viaggio----------------------------//
	public static void compraTV() {
		// Titoli Viaggio //BiglietteriaDAO.infoPuntoVenditaByID("PV671699"))
		// tViaggioList.add(TitoloViaggioDAO.acquistaTitoloViaggio(generaNum("M"),
		// UtenteDAO.trovaUtenteById(1).getNumeroTessera(), TipoTitolo.SETTIMANALE,
		// BiglietteriaDAO.infoPuntoVenditaByID("AUT-001")));
		tViaggioList.add(TitoloViaggioDAO.acquistaTitoloViaggio(generaNum("B"), null, TipoTitolo.BIGLIETTO,
				BiglietteriaDAO.infoPuntoVenditaByID("RIV-002")));
		tViaggioList.add(
				TitoloViaggioDAO.acquistaTitoloViaggio(generaNum("S"), UtenteDAO.trovaUtenteById(3).getNumeroTessera(),
						TipoTitolo.SETTIMANALE, BiglietteriaDAO.infoPuntoVenditaByID("RIV-002")));
		TitoloViaggioDAO.salvaTitoliDiViaggio(tViaggioList);
	}

	public static String generaNum(String code) {
		HashSet<Integer> init = new HashSet<>();
		Random r = new Random();
		int min = 100000;
		int max = 999999;
		int n = 0;

		do {
			n = min + (int) (r.nextDouble() * (max - min));
		} while (init.contains(n));

		init.add(n);
		String result = code + n;

		return result;
	}
	// ricorda di automatizzare generaNum() per controllo tipo || cambiare il
	// foreign key ||
}