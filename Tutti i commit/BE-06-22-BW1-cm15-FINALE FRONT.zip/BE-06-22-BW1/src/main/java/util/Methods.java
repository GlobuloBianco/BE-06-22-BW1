package util;

import java.time.LocalDate;
import java.util.HashSet;
import java.util.Random;
import java.util.Scanner;
import javax.persistence.NoResultException;
import app.Main;
import dao.BiglietteriaDAO;
import dao.TesseraDAO;
import dao.TitoloViaggioDAO;
import dao.UtenteDAO;
import entities.Biglietteria;
import entities.Tessera;
import entities.TitoloDiViaggio;
import entities.Biglietteria.StatoServizio;
import entities.Biglietteria.TipoEnte;
import entities.TitoloDiViaggio.TipoTitolo;

public class Methods {
	// ----------------------------------------Interfaccia Utente----------------------------------------//
	public static void compraBiglietto() {
		Scanner s = new Scanner(System.in);
		BiglietteriaDAO.getListaPV();
		System.out.println("Lista di punti vendita disponibili: ");
		System.out.println("Inserisci il codice del punto vendita: ");
		String sceltaP = s.nextLine();
		Biglietteria result = BiglietteriaDAO.infoPuntoVenditaByID(sceltaP, () -> Main.opzioniGestore());
		if (result.getStatoServizio() == StatoServizio.FUORI_SERVIZIO) {
			System.out.println("Il punto vendita è fuori servizio..");
			compraBiglietto();
		}
		TitoloDiViaggio biglietto = TitoloViaggioDAO.acquistaTitoloViaggio(generaNum("B"), null, TipoTitolo.BIGLIETTO,
				result);
		TitoloViaggioDAO.save(biglietto);
		System.out.println("Dettagli biglietto acquistato: \n" + biglietto.toString());
		Main.opzioniUtente();
	}

	public static void creaUtente() {
		Scanner r = new Scanner(System.in);
		System.out.println("Inserisci il tuo nome e cognome: ");
		String sceltaNome = r.nextLine();
		System.out.println("Inserisci la tua data di nascita in formato YYYY-MM-DD: ");
		String sceltaData = r.nextLine();
		System.out.println("Inserisci la tua email: ");
		String sceltaAdd = r.nextLine();

		Tessera tessera = TesseraDAO.creaTessera(generaNum("UT"), LocalDate.now());
		TesseraDAO.save(tessera);
		UtenteDAO.save(UtenteDAO.creaUtente(sceltaNome, sceltaData, sceltaAdd, tessera));
		System.out.println("Ecco il tuo nuovo numero di tessera: " + tessera.getId());
		System.out.println("Ora puoi acquistare abbonamenti settimanali e mensili!");
		Main.opzioniUtente();

	}

	public static void compraAbbonamento() {
		Scanner y = new Scanner(System.in);
		boolean flag = true;
		while (flag) {
			System.out.println("Inserisci il numero della tua tessera per continuare: \n ");
			String tesseraId = y.nextLine();

			try {
				Tessera tessera = TesseraDAO.getInfoByIdTesseraAbbonamento(tesseraId);
				System.out.println("Codice tessera: " + tessera.getId() + "\nAbbonamento: " + (tessera.getTipologia() != null ? tessera.getTipologia() : "Nessun abbonamento"));
				BiglietteriaDAO.getListaPV();
				System.out.println("Inserisci il codice del punto vendita: ");
				String pvId = (y.nextLine()).toUpperCase();
				Biglietteria puntoVendita = BiglietteriaDAO.infoPuntoVenditaByID(pvId, () -> compraAbbonamento());
				if (puntoVendita.getStatoServizio() == StatoServizio.FUORI_SERVIZIO) {
					System.out.println("Il punto vendita è fuori servizio..");
					compraAbbonamento();
				}
				System.out.println("Digita per acquistare: (1) Abbonamento settimanale - (2) Abbonamento mensile");
				String tipoAbb = y.nextLine();

				if (tipoAbb.equals("1") || tipoAbb.equals("2")) {
					switch (tipoAbb) {
					case "1":
						// acquista settimanale
						if (tessera.getTipologia() == TipoTitolo.SETTIMANALE) {
							while(true) {
								System.out.println(
										"L'abbonamento settimanale è già presente, vuoi estendere la durata? [ Si - No ]");
								String risposta = (y.nextLine()).toUpperCase();
								if (risposta.equals("SI")) {
									tessera.setDataScadenzaAbb(tessera.getDataScadenzaAbb().plusWeeks(1));
									TesseraDAO.save(tessera);
									System.out.println("La durata dell'abbonamento è stata estesa.");
									Main.opzioniUtente();
									break;
								} else if (risposta.equals("NO")) {
									Main.opzioniUtente();
									break;
								} else {
									System.out.println("Risposta non valida");
								}
							}

						} else {
							TitoloDiViaggio s = TitoloViaggioDAO.acquistaTitoloViaggio(generaNum("S"), tessera,
									TipoTitolo.SETTIMANALE, puntoVendita);
							TitoloViaggioDAO.save(s);
							Main.opzioniUtente();
							break;
						}
						break;
					case "2":
						// acquista mensile
						if (tessera.getTipologia() == TipoTitolo.MENSILE) {
							while(true) {
								System.out.println(
										"L'abbonamento mensile è già presente, vuoi estendere la durata? [ Si - No ]");
								String risposta = (y.nextLine()).toUpperCase();
								if (risposta.equals("SI")) {
									tessera.setDataScadenzaAbb(tessera.getDataScadenzaAbb().plusMonths(1));
									TesseraDAO.save(tessera);
									System.out.println("La durata dell'abbonamento è stata estesa.");
									Main.opzioniUtente();
									break;
								} else if (risposta.equals("NO")) {
									Main.opzioniUtente();
									break;
								} else {
									System.out.println("Risposta non valida");
								}
							}
						} else {
							TitoloDiViaggio m = TitoloViaggioDAO.acquistaTitoloViaggio(generaNum("M"), tessera,
									TipoTitolo.MENSILE, puntoVendita);
							TitoloViaggioDAO.save(m);
							Main.opzioniUtente();
							break;
						}
					}
				} else {
					System.out.println("Scelta non valida. Riprovare.");
					compraAbbonamento();
				}
				flag = false;

			} catch (NoResultException e) {
				System.out.println("La tessera non è stata trovata!");
				compraAbbonamento();
			}
		}
	}

	public static void controlloTesseraUtente() {
		Scanner ut = new Scanner(System.in);
		System.out.println("Inserisci il tuo numero di tessera da controllare: ");
		String sceltaT;
		sceltaT = ut.nextLine();

		TesseraDAO.getInfoByIdTessera(sceltaT);
		Main.opzioniUtente();

	}

	// ----------------------------------------Interfaccia Gestore----------------------------------------//

	public static void controlloTessera() {
		Scanner in = new Scanner(System.in);
		System.out.println("Inserisci il numero di tessera da controllare: ");
		String sceltaT;
		sceltaT = in.nextLine();

		TesseraDAO.getInfoByIdTessera(sceltaT);
		Main.opzioniGestore();

	}

	public static void creaPuntoVendita() {
		Scanner pv = new Scanner(System.in);
		System.out.println(
				"Scegli (1) per creare Rivenditore Autorizzato\nScegli (2) per creare Distributore Automatico");
		String sceltaTipo = pv.nextLine();
		while (!sceltaTipo.equals("1") && !sceltaTipo.equals("2")) {
			System.out.println("Scelta non valida. Riprovare.");
			sceltaTipo = pv.nextLine();
		}
		switch (sceltaTipo) {
		case "1":
			System.out.println("Rivenditore autorizzato aggiunto con successo!");
			BiglietteriaDAO.savePV(BiglietteriaDAO.creaPuntoVendita(generaNum("RIV"), TipoEnte.RIVENDITORE_AUTORIZZATO));
			Main.opzioniGestore();
			break;
		case "2":
			System.out.println("Distributore automatico creato con successo!");
			BiglietteriaDAO.savePV(BiglietteriaDAO.creaPuntoVendita(generaNum("AUT"), TipoEnte.DISTRIBUTORE_AUTOMATICO));
			Main.opzioniGestore();
			break;
		}
	}

	public static void modificaPV() {

		Scanner mpv = new Scanner(System.in);
		BiglietteriaDAO.getListaPVCompleta();
		System.out.println("Inserisci il codice del punto vendita da modificare: ");
		String sceltaId = mpv.nextLine();
		BiglietteriaDAO.infoPuntoVenditaByID(sceltaId, () -> Methods.modificaPV());
		System.out.println("Digita (1) per attivare il punto vendita\nDigita (2) per disattivare il punto vendita");
		String sceltax = mpv.nextLine();
		while (!sceltax.equals("1") && !sceltax.equals("2")) {
			System.out.println("Scelta non valida. Riprovare.");
			sceltax = mpv.nextLine();
		}
		switch (sceltax) {
		case "1":
			BiglietteriaDAO.cambiaStato(sceltaId, StatoServizio.ATTIVO);
			Main.opzioniGestore();
			break;
		case "2":
			BiglietteriaDAO.cambiaStato(sceltaId, StatoServizio.FUORI_SERVIZIO);
			Main.opzioniGestore();
			break;
		}
	}

	public static void controllaEmissioniPv() {
		Scanner x= new Scanner(System.in);
		BiglietteriaDAO.getListaPVCompleta();
		System.out.println("Inserisci il codice identificativo del punto vendita");
		String sceltaId = x.nextLine();
		System.out.println("Codice identificativo: "
				+ BiglietteriaDAO.infoPuntoVenditaByID(sceltaId, () -> Main.opzioniGestore()).getId()
				+ "\nQuantità emessa: "
				+ BiglietteriaDAO.infoPuntoVenditaByID(sceltaId, () -> Main.opzioniGestore()).getQtyEmessa());

	}

	// ----------------------------------------Generatore di Numero----------------------------------------//
	public static String generaNum(String code) {
		HashSet<Integer> init = new HashSet<>();
		Random r = new Random();
		int min = 100000;
		int max = 999999;
		int n = 0;

		do {
			n = min + (int) (r.nextDouble() * (max - min));
		} while (init.contains(n));

		init.add(n);
		String result = code + n;

		return result;
	}

	// ------------------------------Richiamo di metodi nei parametri con lambda------------------------------//
	public interface Function {
		void call();
	}

}
