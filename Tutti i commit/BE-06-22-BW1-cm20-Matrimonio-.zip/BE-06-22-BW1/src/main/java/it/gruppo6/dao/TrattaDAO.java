package it.gruppo6.dao;

import java.util.Scanner;

import javax.persistence.EntityManager;

import it.gruppo6.entities.Tratte;
import it.gruppo6.entities.Veicoli;
import it.gruppo6.util.JpaUtil;

public class TrattaDAO extends JpaUtil {
	public static void save(Tratte tr) {
		try {
			t.begin();
			em.persist(tr);
			t.commit();
		} catch (Exception x) {
			System.out.println("Ops! Qualcosa è andato storto nel salvataggio della tratta.");
		}
	}
	
	// AGGIUNGO UN VEICOLO A UNA TRATTA
	public static void aggiungiVeicoloATratta() {
		Scanner myObj = new Scanner(System.in);
		try {
			EntityManager em = JpaUtil.getEntityManagerFactory().createEntityManager();
			em.getTransaction().begin();
			// INSERISCO L'ID DELLA TRATTA CHE VOGLIO
			System.out.println("Inserire id tratta: ");
			long id_tratta;
			long id_veicolo;
			while (true) {
				try {
					id_tratta = Long.parseLong(myObj.nextLine());
					Tratte tratta = em.find(Tratte.class, id_tratta);
					if (tratta == null) {
						System.err.println("Tratta con id " + id_tratta + " non esistente");
						System.out.println("Inserire id tratta: ");
						continue;
					}
					System.out.println("Inserire id veicolo: ");
					id_veicolo = Long.parseLong(myObj.nextLine());
					Veicoli veicolo = em.find(Veicoli.class, id_veicolo);
					if (veicolo == null) {
						System.err.println("Veicolo con id " + id_veicolo + " non esistente");
						System.out.println("Inserire id tratta: ");
						continue;
					}
					if (veicolo.getTratta() != null) {
						System.err.println("Il veicolo con id " + id_veicolo + " è gia assegnato ad un'altra tratta");
						System.out.println("Inserire id tratta: ");
						continue;
					}
					if (tratta.getVeicoli().contains(veicolo)) {
						System.err.println(
								"Il veicolo con id " + id_veicolo + " è gia assegnato alla tratta " + id_tratta);
						System.out.println("Inserire id tratta: ");
						continue;
					}
					tratta.getVeicoli().add(veicolo);
					veicolo.setTratta(tratta);
					System.out.println("Aggiunto correttamente il veicolo con id: " + id_veicolo
							+ " alla tratta con id: " + tratta.getPuntoPartenza() + "-" + tratta.getArrivo());
					em.merge(tratta);
					em.merge(veicolo);
					em.getTransaction().commit();
					em.close();
					break;
				} catch (NumberFormatException e) {
					System.out.println("Devi inserire un numero");
				}
			}
			// INSERISCO L'ID DEL VEICOLO
			// AGGIUNGO IL VEICOLO ALLA TRATTA
		} catch (Exception e) {
			JpaUtil.getEntityManagerFactory().createEntityManager().getTransaction().rollback();
			throw e;
		}

		/*
		Scanner myObj = new Scanner(System.in);
			long id_tratta = 0;
			long id_veicolo;
			
			while (true) {
					// INSERISCO L'ID DELLA TRATTA CHE VOGLIO
					System.out.println("Inserire l'id della tratta da assocciare al veicolo: ");
				try {
					id_tratta = Long.parseLong(myObj.nextLine());
					try {
						Tratte tratta = em.find(Tratte.class, id_tratta);
						if (tratta.getClass() == null) {}
					} catch ( NullPointerException x) {
						System.out.println("l'id inserito non valido.");
						aggiungiVeicoloATratta();
					}
				} catch (NumberFormatException e) {
					System.out.println("Devi inserire un numero.");
					aggiungiVeicoloATratta();
				}
				try {
					System.out.println("Inserire id veicolo: ");
					id_veicolo = Long.parseLong(myObj.nextLine());
					Veicoli veicolo = em.find(Veicoli.class, id_veicolo);
					if (veicolo.getTratta() != null) {
						System.err.println("Il veicolo con id " + id_veicolo + " è gia assegnato ad un'altra tratta");
					}
					if (em.find(Tratte.class, id_tratta).getVeicoli().contains(veicolo)) {
						System.err.println( "Il veicolo con id " + id_veicolo + " è gia assegnato alla tratta " + id_tratta);
					}
					em.find(Tratte.class, id_tratta).getVeicoli().add(veicolo);
					veicolo.setTratta(em.find(Tratte.class, id_tratta));
					System.out.println("Aggiunto correttamente il veicolo con id: " + id_veicolo
							+ " alla tratta con id: " + em.find(Tratte.class, id_tratta).getPuntoPartenza() + "-" + em.find(Tratte.class, id_tratta).getArrivo());
					em.merge(em.find(Tratte.class, id_tratta));
					em.merge(veicolo);
					t.commit();
					break;
				} catch (Exception e) {
					System.out.println("Veicolo inesistente.");
				}
			} */
	}
}
