package it.gruppo6.dao;

import java.time.LocalDateTime;
import javax.persistence.EntityManager;
import javax.persistence.EntityTransaction;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import it.gruppo6.entities.Biglietteria;
import it.gruppo6.entities.Manutenzioni;
import it.gruppo6.entities.Veicoli;
import it.gruppo6.entities.Veicoli.StatoManutenzione;
import it.gruppo6.entities.Veicoli.TipologiaVeicolo;
import it.gruppo6.util.JpaUtil;


public class MezziDAO extends JpaUtil {

	public static void save(Veicoli v) {
		try {
			t.begin();
			em.persist(v);
			t.commit();
		} catch (Exception x) {
			System.out.println("Ops! Qualcosa è andato storto nel salvataggio del mezzo.");
		}
	}

	public static void deleteObj(Veicoli object) {
		try {
			t.begin();
			em.remove(object);
			t.commit();
		} catch (Exception x) {
			System.out.println("Ops! Qualcosa è andato storto nell'eliminazione del mezzo");
		}
	}

	public static void persist(Object entity) {
		try {
			t.begin();
			em.merge(entity);
			t.commit();
		} catch (Exception x) {
			System.out.println("Ops! Qualcosa è andato storto.");
		}
	}

	public static void deleteById(Long id) {
		Veicoli m = em.find(Veicoli.class, id);
		if (m == null) {
			System.out.println("Il mezzo con l'id " + id + " non è stato trovato!");
			return;
		}
		deleteObj(m);
	}

	public static Veicoli getById(Long id) {
		try {
			return em.find(Veicoli.class, id);
		} finally {
			em.close();
		}
	}
	//----------------------------------------------------------------------------------//	

	public static void manutenzione(long id) {
		Manutenzioni m = em.find(Manutenzioni.class, id);
		Veicoli v = em.find(Veicoli.class, id);
		int ggManutenzione = 0;
		if (v.getTipoVeicolo() == TipologiaVeicolo.TRAM) {
			ggManutenzione = 20;
		} else if (v.getTipoVeicolo() == TipologiaVeicolo.BUS) {
			ggManutenzione = 10;
		}
		if ((v.getStato() == StatoManutenzione.COMPLETATO) || (v.getStato() == StatoManutenzione.IN_SERVIZIO)) {
			v.setStato(StatoManutenzione.MANUTENZIONE);
			System.out.println("Il veicolo " + id + " è in manutenzione");
			m.setDataInizioManutenzione(LocalDateTime.now());
			m.setDataFineManutenzione(LocalDateTime.now().plusDays(ggManutenzione));
		}
		else {
			v.setStato(StatoManutenzione.COMPLETATO);
			System.out.println("Il veicolo " + id + " è attivo");
			m.setDataInizioManutenzione(null);
			m.setDataFineManutenzione(null);
		}
		persist(v);
		ManutenzioneDAO.save(m);
	}
}

