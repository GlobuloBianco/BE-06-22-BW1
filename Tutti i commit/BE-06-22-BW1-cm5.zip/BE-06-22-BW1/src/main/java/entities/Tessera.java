package entities;
import java.time.LocalDate;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class Tessera {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int id;
	
	private String tessera;
	private LocalDate dataInizio;
	private LocalDate dataScadenza;
	
	
	

	public LocalDate getDataInizio() {
		return dataInizio;
	}

	public void setDataInizio(LocalDate dataInizio) {
		this.dataInizio = dataInizio;
	}

	public int getId() {
		return id;
	}
	
	public void setDataScadenza(LocalDate dataScadenza) {
		this.dataScadenza = dataScadenza;
	}

	public void setId(int id) {
		this.id = id;
	}

	public LocalDate getDataScadenza() {
		return dataScadenza;
	}

	public String getTessera() {
		return tessera;
	}

	public void setTessera(String numTessera) {
		this.tessera = numTessera;
	}
	

	@Override
	public String toString() {
		return "Tessera [ id= " + id + " | dataInizio= " + dataInizio + " | dataScadenza= " + dataScadenza + " ]";
	}
}
