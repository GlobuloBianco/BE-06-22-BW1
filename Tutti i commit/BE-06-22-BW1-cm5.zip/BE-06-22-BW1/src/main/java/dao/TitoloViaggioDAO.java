package dao;

import java.util.ArrayList;

import entities.Biglietteria;
import entities.TitoloDiViaggio;
import entities.Utente;
import entities.TitoloDiViaggio.TipoTitolo;
import util.JpaUtil;

public class TitoloViaggioDAO extends JpaUtil{
	
	
	public static void save(TitoloDiViaggio tv) {
		try {
			t.begin();
			em.persist(tv);
			t.commit();
		} catch (Exception x) {
			System.out.println("Ops! Qualcosa è andato storto... Riprova!");
		}
	}
	
	/*
	public static void acquistaAbbonamento(int numT, TipoTitolo tipo) {
		Tessera abbonato = controllaAbbonamento(numT);
		LocalDate ora = LocalDate.now();
		try {	//se non è scaduto la tessera
			if ((abbonato.getDataScadenza().isAfter(ora))) {
				abbonato.setTipoTitolo(tipo);
				save(abbonato);
				System.out.println("Abbonamento ricaricato con successo");
			} else {
				System.out.println("La tua tessera è scaduta!");
			}
		} catch (NullPointerException l) {
			System.out.println("Non è possibile acquistare l'abbonamento.");
		}
	} */
	
	public static TitoloDiViaggio acquistaTitoloViaggio(String numB, TipoTitolo tt, Biglietteria luogo) {
		try {
			TitoloDiViaggio tv = new TitoloDiViaggio();
			tv.setNumeroBiglietto(numB);
			tv.setTipoTitolo(tt);
			tv.setLuogoEmissione(luogo);
			System.out.println("Titolo di viaggio acquistato correttamente");
			luogo.setQtyEmessa(luogo.getQtyEmessa() + 1);
			BiglietteriaDAO.save(luogo);
			return tv;
		} catch (Exception e) {
			System.out.println("Non è stato trovato il punto vendita per l'acquisto!");
			return null;
		}

	}
	
	public static void salvaTitoliDiViaggio(ArrayList<TitoloDiViaggio> tvList) {
		try {
			for (TitoloDiViaggio u : tvList) {
				save(u);
			}
			System.out.println("Titoli viaggio salvati con successo!");
		} catch (Exception e) {
			System.out.println("Errore nel salvataggio.");
		}
	}
}
