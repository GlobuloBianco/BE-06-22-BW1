package dao;

import java.util.ArrayList;

import javax.persistence.NoResultException;

import entities.Biglietteria;
import entities.Tessera;
import entities.Biglietteria.StatoServizio;
import entities.Biglietteria.TipoEnte;
import util.JpaUtil;

public class BiglietteriaDAO extends JpaUtil {
	public static void save(Biglietteria b) {
		try {
			t.begin();
			em.persist(b);
			t.commit();
		} catch (Exception x) {
			System.out.println("Ops! Qualcosa è andato storto... Riprova!");
		}
	}
	
	public static Biglietteria creaPuntoVendita(String id, StatoServizio ss, TipoEnte te) {

		Biglietteria b = new Biglietteria();
		b.setId(id);
		b.setQtyEmessa(0);
		b.setStatoServizio(ss);
		b.setTipoEnte(te);
		
		return b;
	}
	
	public static Biglietteria infoPuntoVenditaByID(String id) {
		try { 				
	    	Biglietteria b = em.createQuery("SELECT i FROM Biglietteria i WHERE i.id = :id", Biglietteria.class)
	                .setParameter("id", id)
	                .getSingleResult();
	        return b;
		} catch (NoResultException x) {
	        System.out.println("Punto vendita non trovato!");
	        return null;
	    }
	}
	
	public static void salvaBiglietteria(ArrayList<Biglietteria> bList) {
		try {
			for (Biglietteria b : bList) {
				save(b);
			}
			System.out.println("Punti vendita salvati con successo!");
		} catch (Exception e) {
			System.out.println("Errore nel salvataggio.");
		}
	}
}
