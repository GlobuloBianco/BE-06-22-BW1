package app;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Random;

import dao.BiglietteriaDAO;
import dao.TesseraDAO;
import dao.TitoloViaggioDAO;
import dao.UtenteDAO;
import entities.Biglietteria;
import entities.Tessera;
import entities.TitoloDiViaggio;
import entities.Biglietteria.StatoServizio;
import entities.Biglietteria.TipoEnte;
import entities.TitoloDiViaggio.TipoTitolo;
import entities.Utente;


public class Main {
	//----------------------------------------------------------------------!!
	//-------------------------switch per attivare--------------------------!!
						static boolean crea = true;
						
    //----------------------------------------------------------------------!!
    //----------------------------------------------------------------------!!
	static ArrayList<Utente> userList = new ArrayList<Utente>();
	static ArrayList<Tessera> tessereList = new ArrayList<Tessera>();
	static ArrayList<Biglietteria> biglietteriaList = new ArrayList<Biglietteria>();
	static ArrayList<TitoloDiViaggio> tViaggioList = new ArrayList<TitoloDiViaggio>();
	
	public static void main(String[] args) {
		if (crea) crea();

	}
	
	public static void crea() {
		//Utenti
		userList.add(UtenteDAO.creaUtente("Mario Rossi", "2002-02-21", "Via del Lago 8",generaNum("UT")));

		//Tessere
		tessereList.add(TesseraDAO.caricaTessera(UtenteDAO.trovaUtenteByTessera("UT307278").getNumeroTessera(), LocalDate.parse("2022-12-20")));
		
		//Biglietteria -Punto vendita
		biglietteriaList.add(BiglietteriaDAO.creaPuntoVendita(generaNum("AUT"),StatoServizio.ATTIVO, TipoEnte.DISTRIBUTORE_AUTOMATICO));
		biglietteriaList.add(BiglietteriaDAO.creaPuntoVendita(generaNum("RIV"),StatoServizio.ATTIVO, TipoEnte.RIVENDITORE_AUTORIZZATO));
		biglietteriaList.add(BiglietteriaDAO.creaPuntoVendita(generaNum("RIV"),StatoServizio.ATTIVO, TipoEnte.RIVENDITORE_AUTORIZZATO));

		//Titoli Viaggio
		tViaggioList.add(TitoloViaggioDAO.acquistaTitoloViaggio(generaNum("M"), TipoTitolo.MENSILE, BiglietteriaDAO.infoPuntoVenditaByID("PV671699")));
		tViaggioList.add(TitoloViaggioDAO.acquistaTitoloViaggio(generaNum("B"), TipoTitolo.BIGLIETTO, BiglietteriaDAO.infoPuntoVenditaByID("PV671699")));
		tViaggioList.add(TitoloViaggioDAO.acquistaTitoloViaggio(generaNum("S"), TipoTitolo.SETTIMANALE, BiglietteriaDAO.infoPuntoVenditaByID("PV671699")));

		//salvataggi
		UtenteDAO.salvaUtenti(userList);
		TesseraDAO.salvaTessere(tessereList);
		TitoloViaggioDAO.salvaTitoliDiViaggio(tViaggioList);
		BiglietteriaDAO.salvaBiglietteria(biglietteriaList);

	}

	public static String generaNum(String code) {
		HashSet<Integer> init = new HashSet<>();
		Random r = new Random();
		int min = 100000;
		int max = 999999;
        int n = 0;
        
        do {
            n = min + (int)(r.nextDouble()*(max - min));
        } while (init.contains(n));
        
        init.add(n);
        String result = code+n;
        
        return result;
	}
}