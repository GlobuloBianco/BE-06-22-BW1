package dao;

import javax.persistence.NoResultException;

import entities.Utente;
import util.JpaUtil;


public class UtenteDAO extends JpaUtil {
	public static void save(Utente user) {
		try {
			t.begin();
			em.persist(user);
			t.commit();
		} catch (Exception x) {
			System.out.println("Ops! Qualcosa è andato storto... Riprova!");
		}
	}
	
	public static Utente creaUtente(String username, String data, String indirizzo, int num) {

		Utente u = new Utente();
		u.setUsername(username);
		u.setDataNascita(data);
		u.setIndirizzo(indirizzo);
		u.setNumeroTessera(num);
		return u;
	}
	

	public static Utente trovaUtenteByTessera(int numT) {
		try { 						  //SELECT * FROM public.tessera WHERE id = 91376784
	    	Utente u = em.createQuery("SELECT t FROM Utente t WHERE t.numeroTessera = :tes", Utente.class)
	                .setParameter("tes", numT)
	                .getSingleResult();
	        return u;
		} catch (NoResultException x) {
	        System.out.println("Tessera non trovata!");
	        return null;
	    }
	}
	
}
