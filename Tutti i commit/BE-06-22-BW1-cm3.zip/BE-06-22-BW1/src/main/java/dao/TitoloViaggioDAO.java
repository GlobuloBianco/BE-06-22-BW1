package dao;

import entities.Biglietteria;
import entities.TitoloDiViaggio;
import entities.TitoloDiViaggio.TipoTitolo;
import util.JpaUtil;

public class TitoloViaggioDAO extends JpaUtil{
	
	
	public static void save(TitoloDiViaggio tv) {
		try {
			t.begin();
			em.persist(tv);
			t.commit();
		} catch (Exception x) {
			System.out.println("Ops! Qualcosa è andato storto... Riprova!");
		}
	}
	
	/*
	public static void acquistaAbbonamento(int numT, TipoTitolo tipo) {
		Tessera abbonato = controllaAbbonamento(numT);
		LocalDate ora = LocalDate.now();
		try {	//se non è scaduto la tessera
			if ((abbonato.getDataScadenza().isAfter(ora))) {
				abbonato.setTipoTitolo(tipo);
				save(abbonato);
				System.out.println("Abbonamento ricaricato con successo");
			} else {
				System.out.println("La tua tessera è scaduta!");
			}
		} catch (NullPointerException l) {
			System.out.println("Non è possibile acquistare l'abbonamento.");
		}
	} */
	
	public static TitoloDiViaggio acquistaTitoloViaggio(int numB, TipoTitolo tt, Biglietteria luogo) {
		TitoloDiViaggio tv = new TitoloDiViaggio();
		tv.setNumeroBiglietto(numB);
		tv.setTipoTitolo(tt);
		tv.setLuogoEmissione(luogo);
		System.out.println("Titolo di viaggio acquistato correttamente");
		luogo.setQtyEmessa(luogo.getQtyEmessa() + 1);
		BiglietteriaDAO.save(luogo);
		return tv;
	}
	
}
