package it.gruppo6.dao;

import java.util.List;
import java.util.Scanner;

import javax.persistence.EntityManager;

import it.gruppo6.app.Main;
import it.gruppo6.entities.Biglietteria.StatoServizio;
import it.gruppo6.entities.TitoloDiViaggio;
import it.gruppo6.entities.Tratte;
import it.gruppo6.entities.Veicoli;
import it.gruppo6.entities.Veicoli.StatoManutenzione;
import it.gruppo6.util.JpaUtil;

public class TrattaDAO extends JpaUtil {
	public static void save(Tratte tr) {
		try {
			t.begin();
			em.persist(tr);
			t.commit();
		} catch (Exception x) {
			System.out.println("Ops! Qualcosa è andato storto nel salvataggio della tratta.");
		}
	}
	
	// AGGIUNGO UN VEICOLO A UNA TRATTA
	public static void aggiungiVeicoloATratta() {
			Scanner myObj = new Scanner(System.in);
			try {
				EntityManager em = JpaUtil.getEntityManagerFactory().createEntityManager();
				em.getTransaction().begin();
				// INSERISCO L'ID DELLA TRATTA CHE VOGLIO
				System.out.println("Inserire l'id della tratta da assocciare al veicolo: ");
				long id_tratta;
				long id_veicolo;
				while (true) {
					try {
						id_tratta = Long.parseLong(myObj.nextLine());
						Tratte tratta = em.find(Tratte.class, id_tratta);
						if (tratta == null) {
							System.err.println("Tratta con id " + id_tratta + " inesistente");
							System.out.println("Inserire l'id della tratta: ");
							continue;
						}
						System.out.println("Inserire id veicolo: ");
						id_veicolo = Long.parseLong(myObj.nextLine());
						Veicoli veicolo = em.find(Veicoli.class, id_veicolo);
						if (veicolo == null) {
							System.err.println("Veicolo con id " + id_veicolo + " inesistente");
							System.out.println("Inserire l'id della tratta: ");
							continue;
						}
						if (veicolo.getTratta() != null) {
							System.err.println("Il veicolo con id " + id_veicolo + " è gia assegnato ad un'altra tratta");
							System.out.println("Inserire l'id della tratta: ");
							continue;
						}
						if (tratta.getVeicoli().contains(veicolo)) {
							System.err.println(
									"Il veicolo con id " + id_veicolo + " è gia assegnato alla tratta " + id_tratta);
							System.out.println("Inserire id tratta: ");
							continue;
						}
						tratta.getVeicoli().add(veicolo);
						veicolo.setTratta(tratta);
						System.out.println("Aggiunto correttamente il veicolo con l'id: " + id_veicolo
								+ " alla tratta: " + tratta.getPuntoPartenza() + "-" + tratta.getArrivo());
						em.merge(tratta);
						em.merge(veicolo);
						em.getTransaction().commit();
						em.close();
						Main.opzioniParcoMezzi();
						break;
					} catch (NumberFormatException e) {
						System.out.println("Devi inserire un numero.");
						aggiungiVeicoloATratta();
					}
				}
				// INSERISCO L'ID DEL VEICOLO
				// AGGIUNGO IL VEICOLO ALLA TRATTA
			} catch (Exception e) {
				t.rollback();
				System.out.println("Errore.");
				aggiungiVeicoloATratta();
				throw e;
			}
	}
	
	public static void eseguiTratta() {
		Scanner myObj = new Scanner(System.in);
		try {
			EntityManager em = JpaUtil.getEntityManagerFactory().createEntityManager();
			List<Tratte> tratte = em.createQuery("SELECT t FROM Tratte t", Tratte.class).getResultList();
			if (tratte.isEmpty()) {
				System.out.println("Nessuna tratta trovata");
				return;
			}
			 System.out.println("Lista delle Tratte e degli id dei veicoli "
					 		 + "\n----------------------------------------");
		      for (int i = 0; i < tratte.size(); i++) {
		         Tratte tratta = tratte.get(i);
		         System.out.println("[Tratta " + (i + 1) + "]: " + tratta.getPuntoPartenza() + " - " + tratta.getArrivo());
		         System.out.println("L'id del veicolo: ");
		         if(tratta.getVeicoli().isEmpty()) {
		        	 System.out.println("[i] Nessun mezzo disponibile per la tratta.");
		         }
		         for (Veicoli vehicle : tratta.getVeicoli()) {
		            System.out.println("ID: " + vehicle.getId() + " " + vehicle.getTipoVeicolo() + " (" + (vehicle.getStato() == StatoManutenzione.IN_SERVIZIO ? "Disponibile": "In manutenzione")+")");
		         }
		         System.out.println();
		      }
		      Veicoli selectedVehicle = null;
		        while (selectedVehicle == null || !selectedVehicle.getStato().equals(StatoManutenzione.IN_SERVIZIO)) {
		            System.out.print("Inserisci l'id di un veicolo in servizio: ");
		            Long vehicleId = myObj.nextLong();
		            selectedVehicle = em.find(Veicoli.class, vehicleId);
		            if (selectedVehicle == null || !selectedVehicle.getStato().equals(StatoManutenzione.IN_SERVIZIO)) {
		                System.out.println("Veicolo non trovato o non in servizio. Si prega di inserire un altro veicolo.");
		            }
		        }
		      Tratte selectedTratta = selectedVehicle.getTratta();
		      selectedTratta.setNumeroVolteTrattoPercorso(selectedTratta.getNumeroVolteTrattoPercorso() + 1);
		      
		      
		      //INSERIRE CODICE VIDIMAZIONE BIGLIETTI
		      Scanner vid = new Scanner(System.in);
		      String input = "";
		    	try {
		    		System.out.println("Inserire il numero del biglietto da vidimare oppure scrivi (0) per tornare indietro.");
		    		input = vid.nextLine();
		    		if (input.equals("0")) {
		    			Main.opzioniParcoMezzi();
		    		}
		    		if (input != "0") {
		    			t.begin();
		    			TitoloDiViaggio biglietto = TitoloViaggioDAO.getBigliettoById(input);
		    			biglietto.setConvalidato(true);
		    			selectedVehicle.setBigliettiVidimati(selectedVehicle.getBigliettiVidimati() + 1);
		    			System.out.println("Il veicolo ha vidimato: " + selectedVehicle.getBigliettiVidimati() + " biglietti");
		    			em.merge(selectedVehicle);
		    			em.merge(biglietto);
		    			t.commit();
		  		      em.getTransaction().begin();
		  		      em.persist(selectedTratta);
		  		      em.getTransaction().commit();
		  		      System.out.println("Tratta avvenuta con successo!");
		  		      Main.opzioniParcoMezzi();
		    		}
		    	} catch (Exception e) {
		    		System.err.println("Inserire un biglietto valido o non ancora convalidato: ");
		    		eseguiTratta();
		    	}


		} catch (Exception e) {
			System.out.println("Si prega di inserire un id valido.");
			eseguiTratta();
		}
	}
}
