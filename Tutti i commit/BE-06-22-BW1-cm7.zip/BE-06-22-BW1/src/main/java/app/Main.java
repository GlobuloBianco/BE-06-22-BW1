package app;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Random;

import dao.BiglietteriaDAO;
import dao.TesseraDAO;
import dao.TitoloViaggioDAO;
import dao.UtenteDAO;
import entities.Biglietteria;
import entities.Tessera;
import entities.TitoloDiViaggio;
import entities.Biglietteria.StatoServizio;
import entities.Biglietteria.TipoEnte;
import entities.TitoloDiViaggio.TipoTitolo;
import entities.Utente;


public class Main {
	//----------------------------------------------------------------------!!
	//-------------------------switch per attivare--------------------------!!
						static boolean crea = false;
						static boolean compraTitoliViaggio = false;
						static boolean getInfo = false;
						static boolean getTotaleEmessi = false;
    //----------------------------------------------------------------------!!
    //----------------------------------------------------------------------!!
	static ArrayList<Utente> userList = new ArrayList<Utente>();
	static ArrayList<Tessera> tessereList = new ArrayList<Tessera>();
	static ArrayList<Biglietteria> biglietteriaList = new ArrayList<Biglietteria>();
	static ArrayList<TitoloDiViaggio> tViaggioList = new ArrayList<TitoloDiViaggio>();
	
	public static void main(String[] args) {

		if (crea) crea();
		if (compraTitoliViaggio) compraTV();
		//validità tessera e abbonamenti
		if (getInfo) System.out.println(TesseraDAO.getInfoByIdTessera("UT920308"));
		//crea totale di titoli di viaggio emessi in tutti i punti vendita
		if (getTotaleEmessi) BiglietteriaDAO.totaleQtyEmessa();
	}
	
	//----------------------------Creazioni----------------------------//
	public static void crea() {
		//Tessere
		tessereList.add(TesseraDAO.creaTessera(generaNum("UT"), LocalDate.parse("2022-12-20")));
		tessereList.add(TesseraDAO.creaTessera(generaNum("UT"), LocalDate.parse("2022-01-12")));
		tessereList.add(TesseraDAO.creaTessera(generaNum("UT"), LocalDate.parse("2022-05-26")));
		TesseraDAO.salvaTessere(tessereList);
		
		//Utenti
		userList.add(UtenteDAO.creaUtente("Mario Rossi", "2002-02-21", "Via del Lago 8", tessereList.get(0)));
		userList.add(UtenteDAO.creaUtente("Luigi Verdi", "2000-12-11", "Via Castelli 2", tessereList.get(1)));
		userList.add(UtenteDAO.creaUtente("Peach Rosi", "1999-06-01", "Via Monti 12", tessereList.get(2)));
		UtenteDAO.salvaUtenti(userList);
		
		//Biglietteria -Punto vendita
		biglietteriaList.add(BiglietteriaDAO.creaPuntoVendita("AUT-001",StatoServizio.ATTIVO, TipoEnte.DISTRIBUTORE_AUTOMATICO));
		biglietteriaList.add(BiglietteriaDAO.creaPuntoVendita("RIV-001",StatoServizio.ATTIVO, TipoEnte.RIVENDITORE_AUTORIZZATO));
		biglietteriaList.add(BiglietteriaDAO.creaPuntoVendita("RIV-002",StatoServizio.ATTIVO, TipoEnte.RIVENDITORE_AUTORIZZATO));
		BiglietteriaDAO.salvaBiglietteria(biglietteriaList);
	}
	
	//----------------------------Compra Titoli di Viaggio----------------------------//
	public static void compraTV() {
		//Titoli Viaggio																//BiglietteriaDAO.infoPuntoVenditaByID("PV671699"))
		tViaggioList.add(TitoloViaggioDAO.acquistaTitoloViaggio(generaNum("M"), UtenteDAO.trovaUtenteById(1).getNumeroTessera(), TipoTitolo.SETTIMANALE, BiglietteriaDAO.infoPuntoVenditaByID("AUT-001")));
		tViaggioList.add(TitoloViaggioDAO.acquistaTitoloViaggio(generaNum("B"), null, TipoTitolo.BIGLIETTO, BiglietteriaDAO.infoPuntoVenditaByID("AUT-001")));
		tViaggioList.add(TitoloViaggioDAO.acquistaTitoloViaggio(generaNum("S"), UtenteDAO.trovaUtenteById(3).getNumeroTessera(), TipoTitolo.SETTIMANALE, BiglietteriaDAO.infoPuntoVenditaByID("RIV-002")));
		TitoloViaggioDAO.salvaTitoliDiViaggio(tViaggioList);
	}

	public static String generaNum(String code) {
		HashSet<Integer> init = new HashSet<>();
		Random r = new Random();
		int min = 100000;
		int max = 999999;
        int n = 0;
        
        do {
            n = min + (int)(r.nextDouble()*(max - min));
        } while (init.contains(n));
        
        init.add(n);
        String result = code+n;
        
        return result;
	}
	// ricorda di automatizzare generaNum() per controllo tipo || cambiare il foreign key || 
}