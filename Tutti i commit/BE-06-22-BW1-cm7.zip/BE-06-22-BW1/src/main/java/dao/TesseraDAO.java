package dao;

import java.time.LocalDate;
import java.util.ArrayList;

import javax.persistence.NoResultException;

import entities.Tessera;
import entities.TitoloDiViaggio;
import entities.Utente;
import util.JpaUtil;

public class TesseraDAO extends JpaUtil {
	public static void save(Tessera te) {
		try {
			t.begin();
			em.persist(te);
			t.commit();
		} catch (Exception x) {
			System.out.println("Ops! Qualcosa è andato storto... Riprova!");
		}
	}
	
	public static Tessera getInfoByIdTessera(String numT) {
		try { 					
	    	Tessera u = em.createQuery("SELECT t FROM Tessera t WHERE t.id = :tes", Tessera.class)
	                .setParameter("tes", numT)
	                .getSingleResult();
	        return u;
		} catch (NoResultException x) {
	        System.out.println("Tessera non trovata!");
	        return null;
	    }
	}
	
	public static Tessera creaTessera(String numTessera, LocalDate data) {
		Tessera t = new Tessera();
		t.setId(numTessera);
		t.setDataInizio(data);
		t.setDataScadenza(data.plusYears(1));
		System.out.println("tessera creata con successo");
		return t;
	}
	
	
	public static void salvaTessere(ArrayList<Tessera> tList) {
		try {
			for (Tessera t : tList) {
				save(t);
			}
			System.out.println("Tessere salvate con successo!");
		} catch (Exception e) {
			System.out.println("Errore nel salvataggio.");
		}
	}
}
